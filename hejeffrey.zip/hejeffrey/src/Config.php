<?php
namespace jeffrey;

trait Config{

    public static $path = './storage';

}